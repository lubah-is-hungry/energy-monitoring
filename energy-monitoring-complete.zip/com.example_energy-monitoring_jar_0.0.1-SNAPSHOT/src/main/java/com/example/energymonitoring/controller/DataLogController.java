package com.example.energymonitoring.controller;

import com.example.energymonitoring.model.DataLog;
import com.example.energymonitoring.service.DataLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Data Logs", description = "Operations for data logs")
@RestController
@RequestMapping("/api/data-logs")
public class DataLogController {

    private final DataLogService service;

    public DataLogController(DataLogService service) {
        this.service = service;
    }

    @Operation(summary = "Get all data logs")
    @GetMapping
    public List<DataLog> getAll() {
        return service.findAll();
    }

    @Operation(summary = "Get data log by id")
    @GetMapping("/{id}")
    public DataLog getById(@PathVariable Integer id) {
        return service.findById(id);
    }

    @Operation(summary = "Create data log")
    @PostMapping
    public DataLog create(@RequestBody DataLog log) {
        return service.save(log);
    }

    @Operation(summary = "Update data log")
    @PutMapping("/{id}")
    public DataLog update(@PathVariable Integer id, @RequestBody DataLog updated) {
        DataLog existing = service.findById(id);
        if (existing == null) return null;
        existing.setLogTime(updated.getLogTime());
        existing.setValue(updated.getValue());
        existing.setUnit(updated.getUnit());
        existing.setSensor(updated.getSensor());
        return service.save(existing);
    }

    @Operation(summary = "Delete data log by id")
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        service.deleteById(id);
    }

    @Operation(summary = "Get logs by sensor id")
    @GetMapping("/sensor/{sensorId}")
    public List<DataLog> getBySensor(@PathVariable Integer sensorId) {
        return service.findBySensorId(sensorId);
    }

    @Operation(summary = "Get logs for a sensor in a time range")
    @GetMapping("/sensor-range")
    public List<DataLog> findBySensorRange(
            @RequestParam Integer sensorId,
            @RequestParam LocalDateTime start,
            @RequestParam LocalDateTime end) {
        return service.findBySensorIdAndRange(sensorId, start, end);
    }

    @Operation(summary = "Get logs between timestamps")
    @GetMapping("/range")
    public List<DataLog> findByTimeRange(
            @RequestParam LocalDateTime start,
            @RequestParam LocalDateTime end) {
        return service.findByTimeRange(start, end);
    }

    @Operation(summary = "Count logs for a sensor")
    @GetMapping("/count/{sensorId}")
    public long countLogs(@PathVariable Integer sensorId) {
        return service.countBySensorId(sensorId);
    }

    @Operation(summary = "Count logs for a sensor (stored procedure)")
    @GetMapping("/count-proc/{sensorId}")
    public Long countLogsSP(@PathVariable Integer sensorId) {
        return service.countBySensorIdUsingProc(sensorId);
    }
}
