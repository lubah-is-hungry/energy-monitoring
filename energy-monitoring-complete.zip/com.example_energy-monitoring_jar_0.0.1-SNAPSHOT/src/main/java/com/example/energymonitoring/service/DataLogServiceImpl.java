package com.example.energymonitoring.service;

import com.example.energymonitoring.model.DataLog;
import com.example.energymonitoring.repository.DataLogRepository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class DataLogServiceImpl implements DataLogService {

    private final DataLogRepository dataLogRepository;

    public DataLogServiceImpl(DataLogRepository dataLogRepository) {
        this.dataLogRepository = dataLogRepository;
    }

    @Override
    public List<DataLog> findAll() {
        return dataLogRepository.findAll();
    }

    @Override
    public DataLog findById(Integer id) {
        Optional<DataLog> opt = dataLogRepository.findById(id);
        return opt.orElse(null);
    }

    @Override
    public DataLog save(DataLog dataLog) {
        return dataLogRepository.save(dataLog);
    }

    @Override
    public void deleteById(Integer id) {
        dataLogRepository.deleteById(id);
    }

    @Override
    public List<DataLog> findBySensorId(Integer sensorId) {
        return dataLogRepository.findBySensorId(sensorId);
    }

    @Override
    public List<DataLog> findBySensorIdAndRange(Integer sensorId, LocalDateTime start, LocalDateTime end) {
        return dataLogRepository.findBySensorAndTimestampBetween(sensorId, start, end);
    }

    @Override
    public List<DataLog> findByTimeRange(LocalDateTime start, LocalDateTime end) {
        return dataLogRepository.findByTimestampBetween(start, end);
    }

    @Override
    public long countBySensorId(Integer sensorId) {
        return dataLogRepository.countBySensorId(sensorId);
    }

    @Override
    public Long countBySensorIdUsingProc(Integer sensorId) {
        return dataLogRepository.countLogsForSensorStoredProc(sensorId);
    }
}
