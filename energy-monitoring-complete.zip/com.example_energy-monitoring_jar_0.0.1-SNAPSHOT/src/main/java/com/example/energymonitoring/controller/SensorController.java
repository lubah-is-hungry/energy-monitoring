package com.example.energymonitoring.controller;

import com.example.energymonitoring.model.Sensor;
import com.example.energymonitoring.repository.SensorRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.time.LocalDate;
import java.util.List;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Sensors", description = "Operations for sensors")
@RestController
@RequestMapping("/api/sensors")
public class SensorController {

    private final SensorRepository repository;

    public SensorController(SensorRepository repository) {
        this.repository = repository;
    }

    @Operation(summary = "Get all sensors")
    @GetMapping
    public List<Sensor> getAll() {
        return repository.findAll();
    }

    @Operation(summary = "Get sensor by id")
    @GetMapping("/{id}")
    public Sensor getById(@Parameter(description = "Sensor id") @PathVariable Integer id) {
        return repository.findById(id).orElse(null);
    }

    @Operation(summary = "Create a sensor")
    @PostMapping
    public Sensor create(@RequestBody Sensor sensor) {
        return repository.save(sensor);
    }

    @Operation(summary = "Update a sensor")
    @PutMapping("/{id}")
    public Sensor update(
            @Parameter(description = "Sensor id") @PathVariable Integer id,
            @RequestBody Sensor updated) {
        return repository.findById(id).map(s -> {
            s.setSensorType(updated.getSensorType());
            s.setStatus(updated.getStatus());
            s.setCalibrationDate(updated.getCalibrationDate());
            s.setEnergySource(updated.getEnergySource());
            return repository.save(s);
        }).orElse(null);
    }

    @Operation(summary = "Delete sensor by id")
    @DeleteMapping("/{id}")
    public void delete(@Parameter(description = "Sensor id") @PathVariable Integer id) {
        repository.deleteById(id);
    }

    @Operation(summary = "Find sensors by status")
    @GetMapping("/status/{status}")
    public List<Sensor> findByStatus(@Parameter(description = "Status") @PathVariable String status) {
        return repository.findByStatus(status);
    }

    @Operation(summary = "Find sensors by type")
    @GetMapping("/type/{type}")
    public List<Sensor> findByType(@Parameter(description = "Sensor type") @PathVariable String type) {
        return repository.findBySensorType(type);
    }

    @Operation(summary = "Find sensors by energy source id")
    @GetMapping("/energy-source/{sourceId}")
    public List<Sensor> findByEnergySource(@Parameter(description = "Energy source id") @PathVariable Integer sourceId) {
        return repository.findByEnergySourceId(sourceId);
    }

    @Operation(summary = "Find sensors calibrated before date")
    @GetMapping("/calibrated-before")
    public List<Sensor> calibratedBefore(@Parameter(description = "Date (yyyy-MM-dd)") @RequestParam LocalDate date) {
        return repository.findByCalibrationDateBefore(date);
    }
}
