package com.example.energymonitoring.service;

import com.example.energymonitoring.model.EnergySource;
import java.time.LocalDate;
import java.util.List;

public interface EnergySourceService {

    List<EnergySource> findAll();

    EnergySource findById(Integer id);

    EnergySource save(EnergySource energySource);

    void deleteById(Integer id);

    List<EnergySource> findBySourceType(String sourceType);

    List<EnergySource> searchByLocation(String keyword);

    List<EnergySource> findByCapacityGreaterThan(Double minCapacity);

    List<EnergySource> findInstalledBetween(LocalDate start, LocalDate end);

    boolean existsBySourceType(String sourceType);

    List<EnergySource> findBySourceTypeAndLocation(String type, String location);
}
