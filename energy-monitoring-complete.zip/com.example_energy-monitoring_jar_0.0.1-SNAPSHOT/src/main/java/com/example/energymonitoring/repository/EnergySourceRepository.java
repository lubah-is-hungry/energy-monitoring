package com.example.energymonitoring.repository;

import com.example.energymonitoring.model.EnergySource;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EnergySourceRepository extends JpaRepository<EnergySource, Integer> {

    @Query(value = "SELECT * FROM energy_source WHERE source_type = :sourceType", nativeQuery = true)
    List<EnergySource> findBySourceType(@Param("sourceType") String sourceType);

    @Query(value = "SELECT * FROM energy_source WHERE location LIKE CONCAT('%', :keyword, '%')", nativeQuery = true)
    List<EnergySource> findByLocationContaining(@Param("keyword") String keyword);

    @Query(value = "SELECT * FROM energy_source WHERE capacity_kw > :capacityKw", nativeQuery = true)
    List<EnergySource> findByCapacityKwGreaterThan(@Param("capacityKw") Double capacityKw);

    @Query(value = "SELECT * FROM energy_source WHERE installation_date BETWEEN :start AND :end", nativeQuery = true)
    List<EnergySource> findByInstallationDateBetween(@Param("start") LocalDate start, @Param("end") LocalDate end);

    @Query(value = "SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END FROM energy_source WHERE source_type = :sourceType", nativeQuery = true)
    boolean existsBySourceType(@Param("sourceType") String sourceType);

    @Query(value = "SELECT * FROM energy_source WHERE source_type = :type AND location = :location", nativeQuery = true)
    List<EnergySource> findBySourceTypeAndLocation(@Param("type") String type, @Param("location") String location);
}
