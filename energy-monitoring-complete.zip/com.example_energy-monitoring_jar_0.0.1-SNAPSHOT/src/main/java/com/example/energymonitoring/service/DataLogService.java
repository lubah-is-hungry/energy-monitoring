package com.example.energymonitoring.service;

import com.example.energymonitoring.model.DataLog;
import java.time.LocalDateTime;
import java.util.List;

public interface DataLogService {

    List<DataLog> findAll();

    DataLog findById(Integer id);

    DataLog save(DataLog dataLog);

    void deleteById(Integer id);

    List<DataLog> findBySensorId(Integer sensorId);

    List<DataLog> findBySensorIdAndRange(Integer sensorId, LocalDateTime start, LocalDateTime end);

    List<DataLog> findByTimeRange(LocalDateTime start, LocalDateTime end);

    long countBySensorId(Integer sensorId);

    Long countBySensorIdUsingProc(Integer sensorId);
}
