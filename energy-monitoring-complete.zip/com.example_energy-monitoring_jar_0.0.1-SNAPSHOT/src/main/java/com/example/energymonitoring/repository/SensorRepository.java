package com.example.energymonitoring.repository;

import com.example.energymonitoring.model.Sensor;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SensorRepository extends JpaRepository<Sensor, Integer> {

    @Query(value = "SELECT * FROM sensor WHERE status = :status", nativeQuery = true)
    List<Sensor> findByStatus(@Param("status") String status);

    @Query(value = "SELECT * FROM sensor WHERE sensor_type = :sensorType", nativeQuery = true)
    List<Sensor> findBySensorType(@Param("sensorType") String sensorType);

    @Query(value = "SELECT * FROM sensor WHERE calibration_date < :date", nativeQuery = true)
    List<Sensor> findByCalibrationDateBefore(@Param("date") LocalDate date);

    @Query(value = "SELECT * FROM sensor WHERE energy_source_id = :energySourceId", nativeQuery = true)
    List<Sensor> findByEnergySourceId(@Param("energySourceId") Integer energySourceId);

    @Query(value = "SELECT s.* FROM sensor s JOIN energy_source es ON s.energy_source_id = es.id WHERE es.source_type = :sourceType", nativeQuery = true)
    List<Sensor> findByEnergySource_SourceType(@Param("sourceType") String sourceType);

    @Query(value = "SELECT COUNT(*) FROM sensor WHERE status = :status", nativeQuery = true)
    long countByStatus(@Param("status") String status);

    @Query(value = "SELECT s.* FROM sensor s JOIN energy_source es ON s.energy_source_id = es.id WHERE es.source_type = :type AND s.status = :status", nativeQuery = true)
    List<Sensor> findByEnergySourceTypeAndStatus(@Param("type") String type, @Param("status") String status);

    @Query(value = "SELECT COUNT(*) FROM sensor WHERE energy_source_id = :sourceId", nativeQuery = true)
    long countByEnergySourceId(@Param("sourceId") Integer sourceId);

    @Query(value = "SELECT s.* FROM sensor s LEFT JOIN data_log dl ON s.id = dl.sensor_id WHERE s.id = :id", nativeQuery = true)
    Sensor findByIdWithDataLogs(@Param("id") Integer id);
}
