package com.example.energymonitoring.service;

import com.example.energymonitoring.model.EnergySource;
import com.example.energymonitoring.repository.EnergySourceRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class EnergySourceServiceImpl implements EnergySourceService {

    private final EnergySourceRepository repository;

    public EnergySourceServiceImpl(EnergySourceRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<EnergySource> findAll() {
        return repository.findAll();
    }

    @Override
    public EnergySource findById(Integer id) {
        Optional<EnergySource> opt = repository.findById(id);
        return opt.orElse(null);
    }

    @Override
    public EnergySource save(EnergySource energySource) {
        return repository.save(energySource);
    }

    @Override
    public void deleteById(Integer id) {
        repository.deleteById(id);
    }

    @Override
    public List<EnergySource> findBySourceType(String sourceType) {
        return repository.findBySourceType(sourceType);
    }

    @Override
    public List<EnergySource> searchByLocation(String keyword) {
        return repository.findByLocationContaining(keyword);
    }

    @Override
    public List<EnergySource> findByCapacityGreaterThan(Double minCapacity) {
        return repository.findByCapacityKwGreaterThan(minCapacity);
    }

    @Override
    public List<EnergySource> findInstalledBetween(LocalDate start, LocalDate end) {
        return repository.findByInstallationDateBetween(start, end);
    }

    @Override
    public boolean existsBySourceType(String sourceType) {
        return repository.existsBySourceType(sourceType);
    }

    @Override
    public List<EnergySource> findBySourceTypeAndLocation(String type, String location) {
        return repository.findBySourceTypeAndLocation(type, location);
    }
}
