package com.example.energymonitoring.controller;

import com.example.energymonitoring.model.EnergySource;
import com.example.energymonitoring.repository.EnergySourceRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.time.LocalDate;
import java.util.List;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Energy Sources", description = "Operations for energy sources")
@RestController
@RequestMapping("/api/energy-sources")
public class EnergySourceController {

    private final EnergySourceRepository repository;

    public EnergySourceController(EnergySourceRepository repository) {
        this.repository = repository;
    }

    @Operation(summary = "Get all energy sources")
    @GetMapping
    public List<EnergySource> getAll() {
        return repository.findAll();
    }

    @Operation(summary = "Get energy source by id")
    @GetMapping("/{id}")
    public EnergySource getById(@Parameter(description = "EnergySource id") @PathVariable Integer id) {
        return repository.findById(id).orElse(null);
    }

    @Operation(summary = "Create a new energy source")
    @PostMapping
    public EnergySource create(@RequestBody EnergySource energySource) {
        return repository.save(energySource);
    }

    @Operation(summary = "Update an existing energy source")
    @PutMapping("/{id}")
    public EnergySource update(
            @Parameter(description = "EnergySource id") @PathVariable Integer id,
            @RequestBody EnergySource updated) {
        return repository.findById(id).map(es -> {
            es.setSourceType(updated.getSourceType());
            es.setLocation(updated.getLocation());
            es.setCapacityKw(updated.getCapacityKw());
            es.setInstallationDate(updated.getInstallationDate());
            return repository.save(es);
        }).orElse(null);
    }

    @Operation(summary = "Delete energy source by id")
    @DeleteMapping("/{id}")
    public void delete(@Parameter(description = "EnergySource id") @PathVariable Integer id) {
        repository.deleteById(id);
    }

    @Operation(summary = "Find by source type")
    @GetMapping("/type/{type}")
    public List<EnergySource> findByType(@Parameter(description = "Source type") @PathVariable String type) {
        return repository.findBySourceType(type);
    }

    @Operation(summary = "Search by location keyword")
    @GetMapping("/search")
    public List<EnergySource> searchLocation(@Parameter(description = "Location keyword") @RequestParam String keyword) {
        return repository.findByLocationContaining(keyword);
    }

    @Operation(summary = "Find by capacity greater than")
    @GetMapping("/capacity")
    public List<EnergySource> findByCapacity(@Parameter(description = "Minimum capacity (kW)") @RequestParam Double min) {
        return repository.findByCapacityKwGreaterThan(min);
    }

    @Operation(summary = "Find installations between dates")
    @GetMapping("/installed-between")
    public List<EnergySource> findBetweenDates(
            @Parameter(description = "Start date (yyyy-MM-dd)") @RequestParam LocalDate start,
            @Parameter(description = "End date (yyyy-MM-dd)") @RequestParam LocalDate end) {
        return repository.findByInstallationDateBetween(start, end);
    }
}
