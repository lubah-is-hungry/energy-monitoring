package com.example.energymonitoring.service;

import com.example.energymonitoring.model.Sensor;
import com.example.energymonitoring.repository.SensorRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class SensorServiceImpl implements SensorService {

    private final SensorRepository repository;

    public SensorServiceImpl(SensorRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<Sensor> findAll() {
        return repository.findAll();
    }

    @Override
    public Sensor findById(Integer id) {
        Optional<Sensor> opt = repository.findById(id);
        return opt.orElse(null);
    }

    @Override
    public Sensor save(Sensor sensor) {
        return repository.save(sensor);
    }

    @Override
    public void deleteById(Integer id) {
        repository.deleteById(id);
    }

    @Override
    public List<Sensor> findByStatus(String status) {
        return repository.findByStatus(status);
    }

    @Override
    public List<Sensor> findBySensorType(String sensorType) {
        return repository.findBySensorType(sensorType);
    }

    @Override
    public List<Sensor> findByCalibrationDateBefore(LocalDate date) {
        return repository.findByCalibrationDateBefore(date);
    }

    @Override
    public List<Sensor> findByEnergySourceId(Integer energySourceId) {
        return repository.findByEnergySourceId(energySourceId);
    }

    @Override
    public long countByStatus(String status) {
        return repository.countByStatus(status);
    }
}

