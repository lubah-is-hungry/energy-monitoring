package com.example.energymonitoring.service;

import com.example.energymonitoring.model.Sensor;
import java.time.LocalDate;
import java.util.List;

public interface SensorService {

    List<Sensor> findAll();

    Sensor findById(Integer id);

    Sensor save(Sensor sensor);

    void deleteById(Integer id);

    List<Sensor> findByStatus(String status);

    List<Sensor> findBySensorType(String sensorType);

    List<Sensor> findByCalibrationDateBefore(LocalDate date);

    List<Sensor> findByEnergySourceId(Integer energySourceId);

    long countByStatus(String status);
}
