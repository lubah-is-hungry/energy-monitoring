package com.example.energymonitoring.model;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "sensor")
public class Sensor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "sensor_type", nullable = false, length = 30)
    private String sensorType;

    @Column(nullable = false, length = 10)
    private String status;

    @Column(name = "calibration_date")
    private LocalDate calibrationDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "energy_source_id", nullable = false)
    private EnergySource energySource;

    @OneToMany(mappedBy = "sensor")
    private List<DataLog> dataLogs;

    public Sensor() {
    }

    public Integer getId() {
        return id;
    }

    public String getSensorType() {
        return sensorType;
    }

    public void setSensorType(String sensorType) {
        this.sensorType = sensorType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getCalibrationDate() {
        return calibrationDate;
    }

    public void setCalibrationDate(LocalDate calibrationDate) {
        this.calibrationDate = calibrationDate;
    }

    public EnergySource getEnergySource() {
        return energySource;
    }

    public void setEnergySource(EnergySource energySource) {
        this.energySource = energySource;
    }

    public List<DataLog> getDataLogs() {
        return dataLogs;
    }

    public void setDataLogs(List<DataLog> dataLogs) {
        this.dataLogs = dataLogs;
    }

    public void setId(Long id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
