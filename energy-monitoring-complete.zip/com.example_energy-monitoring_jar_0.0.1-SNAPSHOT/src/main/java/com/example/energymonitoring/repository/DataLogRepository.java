package com.example.energymonitoring.repository;

import com.example.energymonitoring.model.DataLog;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DataLogRepository extends JpaRepository<DataLog, Integer> {

    @Query(value = "SELECT * FROM data_log WHERE sensor_id = :sensorId", nativeQuery = true)
    List<DataLog> findBySensorId(@Param("sensorId") Integer sensorId);

    @Query(value = "SELECT * FROM data_log WHERE sensor_id = :sensorId AND log_time BETWEEN :start AND :end", nativeQuery = true)
    List<DataLog> findBySensorAndTimestampBetween(@Param("sensorId") Integer sensorId, @Param("start") LocalDateTime start, @Param("end") LocalDateTime end);

    @Query(value = "SELECT * FROM data_log WHERE unit = :unit", nativeQuery = true)
    List<DataLog> findByUnit(@Param("unit") String unit);

    @Query(value = "SELECT COUNT(*) FROM data_log WHERE sensor_id = :sensorId", nativeQuery = true)
    long countBySensorId(@Param("sensorId") Integer sensorId);

    @Query(value = "SELECT * FROM data_log WHERE log_time BETWEEN :start AND :end", nativeQuery = true)
    List<DataLog> findByTimestampBetween(@Param("start") LocalDateTime start, @Param("end") LocalDateTime end);

    @Query(value = "CALL count_logs_for_sensor(:sensorId)", nativeQuery = true)
    Long countLogsForSensorStoredProc(@Param("sensorId") Integer sensorId);
}
